#------------------------------------------------#
# Program: join_json.py
# Program Status: Complete
# Programmer: Zhuolin He
# Purpose: Script Used to Join Json data, pls
#          change the parameters of the program
#          as needed.
#------------------------------------------------#

import json

# Define write json
def write_json(file,data):
	with open(file,'w') as fp:
		json.dump(data,fp)

file = range(1000,16000,1000)
all_json={}

for i in file:
	
	# File name
	file_name = './test-unlabelled-' + str(i) + '.json'

	# Open file
	with open(file_name,"r",encoding='utf-8') as js:
		json_data = json.load(js)

	# Check
	print(len(json_data.keys()))

	# Update
	all_json.update(json_data)

print(len(all_json.keys()))

# Ouput
file = open("join_test.json","w",encoding='utf-8')
json.dump(all_json, file, ensure_ascii = False, indent = 4)
file.close()

