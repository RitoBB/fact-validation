#------------------------------------------------#
# Program: new_search_filter.py
# Program Status: Complete
# Programmer: Zhuolin He
# Purpose: filter search terms according to option
#------------------------------------------------#

import sys
import spacy
import re
from spacy import displacy


# Option can be test or train
nlp = spacy.load('en_core_web_md')
SPACY_WARNING_IGNORE='W008'

# Define search_filter
def search_filter(results,page=None,sent=None,claim=None,search_term=None,option='test',nlp=nlp,testing=False):

	# Warnings
	# If Option is not recogized, exit program
	if option.lower() not in ['test','train']:
		print("OptionError: Option must be 'test' or 'train'!")
		sys.exit()

	# remove \\
	slash = True
	while slash:
		if "\\" in search_term:
			slash = True
			search_term = search_term.replace('\\','')
		else:
			slash = False

	# If Test
	if option.lower() == 'test':

		# Container
		prim_docs=[]
		spare_docs = []
		evidence = []

		# Filter 1 - Gather all docs where Page perfectly match the search_term
		for doc in results:
			if doc['page'] in search_term or search_term in doc['page']:
				prim_docs.append(doc)
			else:
				spare_docs.append(doc)

		if prim_docs:
			
			for doc in prim_docs:
	
				# Obtain text
				text = doc['text']
	
				# Calculate similarity
				nclaim = nlp(claim.replace(search_term,""))
				ntext = nlp(text)
				sim = nclaim.similarity(ntext)

				# Additional Score
				if doc['page'] == search_term:
					add_score = 1
				else:
					if doc['page'] in search_term:
						add_score = 0.7
					if search_term in doc['page']:
						add_score = 0.3

				evidence.append((doc,sim+add_score))

		if (not prim_docs and spare_docs): # or (prim_docs and evidence==[] and spare_docs):

			for doc in spare_docs:
	
				# Obtain text
				text = doc['text']
	
				# Calculate similarity
				nclaim = nlp(claim.replace(search_term,""))
				ntext = nlp(text)
				sim = nclaim.similarity(ntext)
				evidence.append((doc,sim))


		# Output
		# If evidence found
		if evidence:

			# Sort evidence by similarity
			s_evidence = sorted(evidence,key=lambda tup: tup[1], reverse=True)

			# Containers
			evi_title =[]
			evi_text = []
			evi_sim = []

			# Organize
			for evi in s_evidence:
				evi_title.append([evi[0]["opage"],evi[0]["sent"]])
				evi_text.append(evi[0]["text"])
				evi_sim.append(evi[1])

			output = [evi_title,evi_text,evi_sim]

		# If no evidences
		else:
			output = []

		return output

	# If Train
	if option.lower() == 'train':

		# Process page
		target_page = page
		filtered = " "

		# Find the sentence
		for items in results:
			if items['opage'] == target_page and items['sent'] == sent:
				filtered = items['text']
				break

		return filtered
