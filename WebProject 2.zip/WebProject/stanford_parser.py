#------------------------------------------------#
# Program: stanford_parser.py
# Program Status: Complete
# Programmer: Zhuolin He
# Purpose: stanford parser
#          Input - Sentence
#          Output - Triplets
#------------------------------------------------#
import os
from nltk.parse import stanford
from nltk.tree import Tree
from collections import OrderedDict

# Enviromental Path
os.environ['STANFORD_PARSER'] = 'C:\\Users\\Zhuolin(Joe) He\\Desktop\\Master of Data Science\\Semester 3\\Web\\homeworks\\project\\jars'
os.environ['STANFORD_MODELS'] = 'C:\\Users\\Zhuolin(Joe) He\\Desktop\\Master of Data Science\\Semester 3\\Web\\homeworks\\project\\jars'

# Invoke Parser
parser = stanford.StanfordParser(model_path="C:\\Users\\Zhuolin(Joe) He\\Desktop\\Master of Data Science\\Semester 3\\Web\\homeworks\\project\\sergz\\englishPCFG.ser.gz")

def stanford_keyword(sentence,display=False):

	# Force String
	string = str(sentence)
	
	# Parse the Sentence
	parse_string = parser.raw_parse(string)
	parse_tree = str(list(parse_string)[0])

	# Vie the tree
	print(parse_tree)

	# Parse the tree
	container = []

	for tree in Tree.fromstring(parse_tree).subtrees():
		container.append((tree.label(),tree.leaves()))

	# Testing
	#print(container)

	# Container of NP
	np = None

	# Indicator (if sub-NP is found)
	sub_np = False
	of_comb = False

	# Store Search Term
	search_term = []

	# Loop thru the tree
	for i in range(len(container)):

		# of combination
		if np and "of" in np:
			of_comb = True

		# If NP is found
		if container[i][0] == 'NP':

			# If first NP, store it
			if not np:
				np = container[i][1]

			# If not first NP, see if it's the sub-NP
			else:

				# Store the sub-NP
				if set(container[i][1]).issubset(set(np)):

					# of combination
					if of_comb:
						continue
					else:
						np = container[i][1]

				# If not
				else:

					# Store NP			
					search_term.append(np)

					# Refresh of_comb
					if of_comb:
						of_comb = False

					# Refresh NP
					np = container[i][1]

		# Store NP when we reach the end
		if container[i][0]=='.':
			search_term.append(np)

	# Process Keywords
	keywords = []
	for term in search_term:
		if term:
			keywords.append(" ".join(term))
	keywords=list(OrderedDict.fromkeys(keywords))

	# Remove symbols in keywords
	new_keywords = []
	for kw in keywords:

		# Split for "/"
		if "/" in kw:
			rm_sb = kw.split('/')
			for rm in rm_sb:
				new_keywords.append(rm)

		# Update
		else:
			# Escape
			for c in kw:
				if c in "+-|!()[]^'~*?:":
					kw = kw.replace(c,'\\'+c)
			
			new_keywords.append(kw)


	# Didplay
	if display:
		print('Claim:',sentence)
		print('Key Words:',new_keywords)

	return new_keywords

# Testing
#stanford_triplet("I am Ironman and I am rich, but a jerk.",display=True)
#stanford_keyword("There is a broadcaster named Rupert Murdoch.",display=True)
#stanford_keyword("Her was released in 2013.",display=True)