#------------------------------------------------#
# Program: search_filter.py
# Program Status: Not Complete
# Programmer: Zhuolin He
# Purpose: filter search terms according to option
#------------------------------------------------#

import sys
import spacy
import re
from spacy import displacy


# Option can be test or train
nlp = spacy.load('en_core_web_md')
SPACY_WARNING_IGNORE='W008'

# Define search_filter
def search_filter(results,page=None,sent=None,search_term=None,keywords=None,option='test',nlp=nlp,threshold=0.6,testing=False):

	# Warnings
	# If Option is not recogized, exit program
	if option.lower() not in ['test','train']:
		print("OptionError: Option must be 'test' or 'train'!")
		sys.exit()

	# If Train and no page or sent
	#if option.lower() == 'train' and (not page or not sent):
	#	print("Error: please provide page and sent in training mode!")
	#	sys.exit()

	# If test and no keywords
	#if option.lower() == 'test' and (not keywords or not search_term):
	#	print("Error: please provide keywords in testing mode!")
	#	sys.exit()

	# If Test
	if option.lower() == 'test':

		# Container
		prim_docs=[]
		spare_docs = []
		evidence = []

		# Filter 1 - Gather all docs where Page perfectly match the search_term
		for doc in results:
			if doc['page'].lower() == search_term.lower():
				prim_docs.append(doc)
			else:
				spare_docs.append(doc)

		# Filter 2 - Filter docs by similairty
		# If prime docs are found
		if prim_docs:

			# Loop thru docs in prim docs
			for pdoc in prim_docs:

				# If keywords are provided
				if keywords:
					# Obtain text
					text = pdoc['text']

					# If not, loop thru keywords
					for key in keywords:

						# Calculate similarity
						nkey = nlp(key)
						ntext = nlp(text)
						sim = nkey.similarity(ntext)

						# If similarity is larger than threshold
						if sim >= threshold:
							evidence.append((pdoc,sim))
							break

				# If no keywords provided
				else:
					evidence.append((pdoc,1))
					break

		# if no prim docs are found or evidence is not enouth, we look at spare docs
		if not prim_docs and not evidence:

			# Loop thru docs in spare docs
			for sdoc in spare_docs:

				# If keywords provided
				if keywords:

					# Obtain text
					text = sdoc['text']

					# If not, loop thru keywords
					for key in keywords:

						# Calculate similarity
						nkey = nlp(key)
						ntext = nlp(text)
						sim = nkey.similarity(ntext)

						# If similarity is larger than threshold
						if sim >= threshold+0.1:
							evidence.append((sdoc,sim))
							break

				# If keywords not provided
				else:
					evidence.append((sdoc,1))
					break

		# Output
		# If evidence found
		if evidence:

			# Sort evidence by similarity
			s_evidence = evidence.sort(key=lambda tup: tup[1], reverse=True)

			# Containers
			evi_title =[]
			evi_text = []
			evi_sim = []

			# Organize
			for evi in evidence:
				evi_title.append([evi[0]["opage"],evi[0]["sent"]])
				evi_text.append(evi[0]["text"])
				evi_sim.append(evi[1])

			output = [evi_title,evi_text,evi_sim]

		# If no evidences
		else:
			output = []

		return output

	# If Train
	if option.lower() == 'train':

		# Process page
		target_page = page
		filtered = " "

		# Find the sentence
		for items in results:
			if items['opage'] == target_page and items['sent'] == sent:
				filtered = items['text']
				break

		return filtered
