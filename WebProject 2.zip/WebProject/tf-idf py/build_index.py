#------------------------------------------------#
# Program: build_index.py
# Program Status: Completed
# Programmer: Zhuolin He
# Purpose: Build index(dicitonary) based on wiki
#          documents
#------------------------------------------------#

# Packages
import lucene
from java.nio.file import Paths
import shutil
import time
import os
from os import walk
from org.apache.lucene import analysis,document,index,queryparser,search,store,util
from org.apache.lucene.store import SimpleFSDirectory, Directory

# Virtual Machine
lucene.initVM()

def wiki_index(folder="./index", dic_folder="./wiki-pages-text/"):

	# folder: where the index will be stored (folder will be created if not exist)
	# dic_folder: index will be created based on all the (text) file under this folder

	# Indicator
	build = True

	# Create Folder If Not Exist
	try:
		if not os.path.exists(folder):
			os.makedirs(folder)
		else:
			# Ask User if they want to clear the folder
			warning = folder + " folder exist, would you like to empty the folder and create new index? (yes or no)"
			proceed = str(input(warning))

			# If yes
			if proceed.lower().startswith('y'):
				print("Gotcha! Will continue the build!")
				print()
				build = True
			# If not
			else:
				print("See you next time!")
				print()
				build = False

	except OSError:
		print('Error: Creating Folder - ',folder)

	# If build == True
	if build:

		# Gather Index File
		ifile = []
		for (dirpath, dirnames, filenames) in walk(dic_folder):
			for filename in filenames:
				ifile.append(dirpath+filename)

		# Number of index file
		print("There are ", len(ifile)," text files gathered to build index.")
	
		# Initiate Analyzer
		analyzer = analysis.standard.StandardAnalyzer()
	
		# Clean Folder
		shutil.rmtree(folder)
		
		# Path of Folder
		path = Paths.get(folder)
			
		# To store the index on disc
		directory = SimpleFSDirectory(path)
		config = index.IndexWriterConfig(analyzer)
		writer = index.IndexWriter(directory, config)
		
		# Loop thru each text file
		for text_file in ifile:

			# Record Starting Time
			start_time = time.time()

			# Message
			print("Building index with, ", text_file)

			# Open text file
			with open(text_file,"r",encoding='utf-8') as file:
				
				# Loop Thru lines of the file
				for line in file:

					# Store the line as text
					text = str(line)

					# Retrive Info
					text_split = text.split(" ",2)
					page_id = text_split[0]
					new_page_id = page_id.replace("_"," ")
					sent_id = text_split[1]
					text = text_split[2]

					# Replace Wiki Symbols
					text = text.replace("-SLH-","/")
					text = text.replace("-LRB-","(")
					text = text.replace("-RRB-",")")
					text = text.replace("\n"," ")

					# Testing
					#print(page_id)
					#print(sent_id)
					#print(text)

					# Storing
					doc = document.Document()
					doc.add(document.Field("OPage", page_id, document.TextField.TYPE_STORED))
					doc.add(document.Field("Page", new_page_id, document.TextField.TYPE_STORED))
					doc.add(document.Field("Sentence", sent_id, document.TextField.TYPE_STORED))
					doc.add(document.Field("Text", text, document.TextField.TYPE_STORED))
					doc.add(document.Field("Source", text_file, document.TextField.TYPE_STORED))
					writer.addDocument(doc)

			# Friendly Message
			print("Spent ", round((time.time() - start_time),2), " secs to build the index based on ", text_file)
			print()	

		# Close Writer			
		writer.close()
		
# Testing
#wiki_index(folder="./index_test", dic_folder="./wiki_test/")
wiki_index()