#------------------------------------------------#
# Program: new_fill_json.py
# Program Status: Complete
# Programmer: Zhuolin He
# Purpose: complte the json files with evidence 
#          and senteces with out methods
#------------------------------------------------#

import searcher
import new_search_filter
import stanford_parser
import json
import lucene

#json_file = "./devset.json"
#new_file = "./new_devset.json"

json_file = "./test-unlabelled.json"

# Test
test = True

# Skip?
skip = False

# Define write json
def write_json(file,data):
	with open(file,'w') as fp:
		json.dump(data,fp)

# Load json
with open(json_file,"r",encoding='utf-8') as js:
	json_data = json.load(js)

print('json loaded!')
print(len(json_data.keys()))

# Count
count = 0

# Java Error Count
java_error = 0
java_error_q = {}

# Updated Json
updated_json = {}

# Loop thru json
for key in json_data.keys():

	# Count
	count += 1

	# Grab basics
	json_obj = json_data[key]
	print('Before',json_obj)
	claim = json_obj['claim']
	evidence = None

	# If not doing test
	if not test:
	
		# Update Evi?
		update_evi = False

		# Skip?
		skip = False

		# Obtain objects
		evidence = json_obj['evidence']

		# Collect all evidence text
		evi_text = []

		for evi in evidence:
			q = evi[0]
			s = evi[1]

			# Deal with symbols
			for c in q:
				if c in "+-|!()[]^'~*?:/":
					q = q.replace(c,'\\'+c)

			# Escape Java Error
			try:
				result = searcher.index_searcher(q_text=q, nquery = 50, sfield="OPage", print_result=False, Source=False)
				filtered = new_search_filter.search_filter(results = result, option='train',page=q,sent=s)
				evi_text.append(filtered)
			except lucene.JavaError:
				java_error+=1
				java_error_q[key] = q

	# Evidence exist but nothing is returned
	if evidence:
		# Nothing is found
		if evi_text ==[]:
			skip = True

		# If evi_text is found
		else: 
			cat_text = " ".join(evi_text)

	# If not, fill it with stuff
	else:

		# Update evi!
		update_evi = True

		# Get keywords
		keywords = stanford_parser.stanford_keyword(claim)

		# Search Index
		results = {}
		for kw in keywords:
			result = searcher.index_searcher(q_text=kw, nquery = 50, sfield="Page", print_result=False, Source=False)
			results[kw] = result

		# Filter Search Results
		evidences = []
		index=0

		# If multiple keywords
		for kw in keywords:
			st = keywords[index]
			left = [x for i,x in enumerate(keywords) if i!=index]
			evidence = new_search_filter.search_filter(results = results[kw], claim=claim, search_term = st, option='test')
			evidences.append(evidence)
			index+=1


		# Organize Output
		org_evi = []
		for evi in evidences:

			# Check if evi is empty
			if evi == []:
				continue

			# Organize 0:title 1:text, 2:sim
			for i in range(len(evi[0])):
				org_evi.append((evi[0][i],evi[1][i],evi[2][i]))

		# Sort all evidences
		sorg_evi = sorted(org_evi,key=lambda tup: tup[2], reverse=True)

		# Get top N
		initial = True
		topn = []
		for evi in sorg_evi:
			# Rcord max sim
			if initial:
				max_sim = evi[2]
				initial = False
				topn.append(evi)

			else:
				if max_sim - evi[2] > 0.025:
					break
				else:
					topn.append(evi)

		# If more than 3
		if len(topn) > 3:
			topn = topn[:3]	

		# Container
		cat_text = " "
		cat_evi = []

		# Cat all text
		for i in range(len(topn)):
			cat_text = cat_text + " " + topn[i][1]
			cat_evi.append(topn[i][0])

	# Update Json if not skip
	if not skip:

		json_obj['sentences'] = cat_text
		if update_evi:
			json_obj['evidence'] = cat_evi

		updated_json[key] = json_obj

		print('After',json_obj)
		print('key',key)
		print('Count',count)

	# Reset Skip
	skip = False

	if count % 1000 == 0 or count == len(json_data.keys()):
		new_file = "./test-unlabelled-" + str(count) + ".json"

		# Output
		write_json(new_file,updated_json)

		# Clear Updated Json
		updated_json = {}
		print("Output:",new_file)

		# Report Jave Error
		print(java_error)
		print(java_error_q)



	

	