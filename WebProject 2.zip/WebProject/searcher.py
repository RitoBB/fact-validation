#------------------------------------------------#
# Program: searcher.py
# Program Status: Compltete
# Programmer: Zhuolin He
# Purpose: Search index(dicitonary) with given
#          query, field and index folder
#------------------------------------------------#

# Packages
import lucene
from java.nio.file import Paths
import time
from org.apache.lucene import analysis,document,index,queryparser,search,store,util
from org.apache.lucene.store import SimpleFSDirectory, Directory

# Virtual Machine
lucene.initVM()

# Settings
folder = "./index"
path = Paths.get(folder)
directory = SimpleFSDirectory(path)
analyzer = analysis.standard.StandardAnalyzer()
reader = index.DirectoryReader.open(directory)
searcher = search.IndexSearcher(reader)

# Define Index_Searcher
def index_searcher(q_text, sfield='Page', nquery=50, folder=folder, print_result=False, Source=False,
	               path=path, directory=directory, analyzer=analyzer, reader=reader, searcher=searcher):

	# Define Parser
	parser = queryparser.classic.QueryParser(sfield, analyzer)
	query = parser.parse(q_text)

	# Hitted documents
	hits = searcher.search(query, nquery).scoreDocs
	
	# Result Container
	Results = []

	# Display Result
	for i, hit in enumerate(hits):

		# Get hitted document
		doc = searcher.doc(hit.doc)

		# Create result for each hitted doc
		result = {}
		result['opage'] = doc.getField('OPage').stringValue()
		result['page'] = doc.getField('Page').stringValue()

		try:
			result['sent'] = int(doc.getField('Sentence').stringValue())
		except ValueError:
			result['sent'] = 99

		result['text'] = doc.getField('Text').stringValue()
		if Source:
			result['source'] = doc.getField('Source').stringValue()

		# Appedn results
		Results.append(result)

	# Print Results if Print == True
	if print_result:
		for i in range(len(Results)):
			print(Results[i])

	# Return all the Results
	return Results
		

# Testing
#index_searcher(q_text="Nikolaj Coster-Waldau",sfield="Text",print_result=True)
#index_searcher(q_text="Fox Broadcasting Company",sfield="Text",print_result=True)
#index_searcher(q_text="Ryan Gosling", nquery = 100, sfield="Page", print_result=True, Source=True)
#index_searcher(q_text="Man\\!_I_Feel_Like_a_Woman\\!", nquery = 50, sfield="OPage", print_result=True, Source=True)
#index_searcher(q_text='Her\\(', nquery = 15, sfield="Page", print_result=True, Source=False)